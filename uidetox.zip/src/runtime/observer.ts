export type Observer = () => void;

let current: Observer | null = null;

export function getCurrentObserver(): Observer | null {
  return current;
}

export function runWithObserver<T>(observer: Observer, fn: () => T): T {
  const prev = current;
  current = observer;
  try {
    return fn();
  } finally {
    current = prev;
  }
}

/** Runs fn without subscribing any reactive reads to the current observer. */
export function untrack<T>(fn: () => T): T {
  const prev = current;
  current = null;
  try {
    return fn();
  } finally {
    current = prev;
  }
}

/** Alias of {@link untrack}. */
export const untracked = untrack;
